#ifndef _ROS_depthai_ros_msgs_TrackDetection2D_h
#define _ROS_depthai_ros_msgs_TrackDetection2D_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "vision_msgs/ObjectHypothesisWithPose.h"
#include "vision_msgs/BoundingBox2D.h"

namespace depthai_ros_msgs
{

  class TrackDetection2D : public ros::Msg
  {
    public:
      uint32_t results_length;
      typedef vision_msgs::ObjectHypothesisWithPose _results_type;
      _results_type st_results;
      _results_type * results;
      typedef vision_msgs::BoundingBox2D _bbox_type;
      _bbox_type bbox;
      typedef bool _is_tracking_type;
      _is_tracking_type is_tracking;
      typedef const char* _tracking_id_type;
      _tracking_id_type tracking_id;
      typedef int32_t _tracking_age_type;
      _tracking_age_type tracking_age;
      typedef int32_t _tracking_status_type;
      _tracking_status_type tracking_status;

    TrackDetection2D():
      results_length(0), st_results(), results(nullptr),
      bbox(),
      is_tracking(0),
      tracking_id(""),
      tracking_age(0),
      tracking_status(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->results_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->results_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->results_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->results_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->results_length);
      for( uint32_t i = 0; i < results_length; i++){
      offset += this->results[i].serialize(outbuffer + offset);
      }
      offset += this->bbox.serialize(outbuffer + offset);
      union {
        bool real;
        uint8_t base;
      } u_is_tracking;
      u_is_tracking.real = this->is_tracking;
      *(outbuffer + offset + 0) = (u_is_tracking.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->is_tracking);
      uint32_t length_tracking_id = strlen(this->tracking_id);
      varToArr(outbuffer + offset, length_tracking_id);
      offset += 4;
      memcpy(outbuffer + offset, this->tracking_id, length_tracking_id);
      offset += length_tracking_id;
      union {
        int32_t real;
        uint32_t base;
      } u_tracking_age;
      u_tracking_age.real = this->tracking_age;
      *(outbuffer + offset + 0) = (u_tracking_age.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_tracking_age.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_tracking_age.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_tracking_age.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->tracking_age);
      union {
        int32_t real;
        uint32_t base;
      } u_tracking_status;
      u_tracking_status.real = this->tracking_status;
      *(outbuffer + offset + 0) = (u_tracking_status.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_tracking_status.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_tracking_status.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_tracking_status.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->tracking_status);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      uint32_t results_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      results_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      results_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      results_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->results_length);
      if(results_lengthT > results_length)
        this->results = (vision_msgs::ObjectHypothesisWithPose*)realloc(this->results, results_lengthT * sizeof(vision_msgs::ObjectHypothesisWithPose));
      results_length = results_lengthT;
      for( uint32_t i = 0; i < results_length; i++){
      offset += this->st_results.deserialize(inbuffer + offset);
        memcpy( &(this->results[i]), &(this->st_results), sizeof(vision_msgs::ObjectHypothesisWithPose));
      }
      offset += this->bbox.deserialize(inbuffer + offset);
      union {
        bool real;
        uint8_t base;
      } u_is_tracking;
      u_is_tracking.base = 0;
      u_is_tracking.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->is_tracking = u_is_tracking.real;
      offset += sizeof(this->is_tracking);
      uint32_t length_tracking_id;
      arrToVar(length_tracking_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_tracking_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_tracking_id-1]=0;
      this->tracking_id = (char *)(inbuffer + offset-1);
      offset += length_tracking_id;
      union {
        int32_t real;
        uint32_t base;
      } u_tracking_age;
      u_tracking_age.base = 0;
      u_tracking_age.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_tracking_age.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_tracking_age.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_tracking_age.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->tracking_age = u_tracking_age.real;
      offset += sizeof(this->tracking_age);
      union {
        int32_t real;
        uint32_t base;
      } u_tracking_status;
      u_tracking_status.base = 0;
      u_tracking_status.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_tracking_status.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_tracking_status.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_tracking_status.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->tracking_status = u_tracking_status.real;
      offset += sizeof(this->tracking_status);
     return offset;
    }

    virtual const char * getType() override { return "depthai_ros_msgs/TrackDetection2D"; };
    virtual const char * getMD5() override { return "8f4e4ea4c4035ce11659980b4d3e8403"; };

  };

}
#endif
