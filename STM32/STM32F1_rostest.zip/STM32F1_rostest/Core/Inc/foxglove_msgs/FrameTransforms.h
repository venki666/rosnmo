#ifndef _ROS_foxglove_msgs_FrameTransforms_h
#define _ROS_foxglove_msgs_FrameTransforms_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "foxglove_msgs/FrameTransform.h"

namespace foxglove_msgs
{

  class FrameTransforms : public ros::Msg
  {
    public:
      uint32_t transforms_length;
      typedef foxglove_msgs::FrameTransform _transforms_type;
      _transforms_type st_transforms;
      _transforms_type * transforms;

    FrameTransforms():
      transforms_length(0), st_transforms(), transforms(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->transforms_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->transforms_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->transforms_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->transforms_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->transforms_length);
      for( uint32_t i = 0; i < transforms_length; i++){
      offset += this->transforms[i].serialize(outbuffer + offset);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      uint32_t transforms_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      transforms_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      transforms_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      transforms_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->transforms_length);
      if(transforms_lengthT > transforms_length)
        this->transforms = (foxglove_msgs::FrameTransform*)realloc(this->transforms, transforms_lengthT * sizeof(foxglove_msgs::FrameTransform));
      transforms_length = transforms_lengthT;
      for( uint32_t i = 0; i < transforms_length; i++){
      offset += this->st_transforms.deserialize(inbuffer + offset);
        memcpy( &(this->transforms[i]), &(this->st_transforms), sizeof(foxglove_msgs::FrameTransform));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/FrameTransforms"; };
    virtual const char * getMD5() override { return "3c5aea4e175ec38d325a55afde5519a8"; };

  };

}
#endif
