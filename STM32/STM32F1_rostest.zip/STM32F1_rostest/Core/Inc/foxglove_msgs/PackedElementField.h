#ifndef _ROS_foxglove_msgs_PackedElementField_h
#define _ROS_foxglove_msgs_PackedElementField_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace foxglove_msgs
{

  class PackedElementField : public ros::Msg
  {
    public:
      typedef const char* _name_type;
      _name_type name;
      typedef uint32_t _offset_type;
      _offset_type offset;
      typedef uint8_t _type_type;
      _type_type type;
      enum { UNKNOWN = 0 };
      enum { UINT8 = 1 };
      enum { INT8 = 2 };
      enum { UINT16 = 3 };
      enum { INT16 = 4 };
      enum { UINT32 = 5 };
      enum { INT32 = 6 };
      enum { FLOAT32 = 7 };
      enum { FLOAT64 = 8 };

    PackedElementField():
      name(""),
      offset(0),
      type(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      uint32_t length_name = strlen(this->name);
      varToArr(outbuffer + offset, length_name);
      offset += 4;
      memcpy(outbuffer + offset, this->name, length_name);
      offset += length_name;
      *(outbuffer + offset + 0) = (this->offset >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->offset >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->offset >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->offset >> (8 * 3)) & 0xFF;
      offset += sizeof(this->offset);
      *(outbuffer + offset + 0) = (this->type >> (8 * 0)) & 0xFF;
      offset += sizeof(this->type);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      uint32_t length_name;
      arrToVar(length_name, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_name; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_name-1]=0;
      this->name = (char *)(inbuffer + offset-1);
      offset += length_name;
      this->offset =  ((uint32_t) (*(inbuffer + offset)));
      this->offset |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->offset |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->offset |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->offset);
      this->type =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->type);
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/PackedElementField"; };
    virtual const char * getMD5() override { return "df41f15dfb434e3b15eedc0c7e914a83"; };

  };

}
#endif
