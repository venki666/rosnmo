#ifndef _ROS_foxglove_msgs_SphereListMarker_h
#define _ROS_foxglove_msgs_SphereListMarker_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "ros/time.h"
#include "ros/duration.h"
#include "foxglove_msgs/KeyValuePair.h"
#include "foxglove_msgs/SphereAttributes.h"

namespace foxglove_msgs
{

  class SphereListMarker : public ros::Msg
  {
    public:
      typedef ros::Time _timestamp_type;
      _timestamp_type timestamp;
      typedef const char* _frame_id_type;
      _frame_id_type frame_id;
      typedef const char* _id_type;
      _id_type id;
      typedef ros::Duration _lifetime_type;
      _lifetime_type lifetime;
      typedef bool _frame_locked_type;
      _frame_locked_type frame_locked;
      uint32_t metadata_length;
      typedef foxglove_msgs::KeyValuePair _metadata_type;
      _metadata_type st_metadata;
      _metadata_type * metadata;
      uint32_t attributes_length;
      typedef foxglove_msgs::SphereAttributes _attributes_type;
      _attributes_type st_attributes;
      _attributes_type * attributes;

    SphereListMarker():
      timestamp(),
      frame_id(""),
      id(""),
      lifetime(),
      frame_locked(0),
      metadata_length(0), st_metadata(), metadata(nullptr),
      attributes_length(0), st_attributes(), attributes(nullptr)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->timestamp.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.sec);
      *(outbuffer + offset + 0) = (this->timestamp.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timestamp.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->timestamp.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->timestamp.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id = strlen(this->frame_id);
      varToArr(outbuffer + offset, length_frame_id);
      offset += 4;
      memcpy(outbuffer + offset, this->frame_id, length_frame_id);
      offset += length_frame_id;
      uint32_t length_id = strlen(this->id);
      varToArr(outbuffer + offset, length_id);
      offset += 4;
      memcpy(outbuffer + offset, this->id, length_id);
      offset += length_id;
      *(outbuffer + offset + 0) = (this->lifetime.sec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->lifetime.sec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->lifetime.sec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->lifetime.sec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->lifetime.sec);
      *(outbuffer + offset + 0) = (this->lifetime.nsec >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->lifetime.nsec >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->lifetime.nsec >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->lifetime.nsec >> (8 * 3)) & 0xFF;
      offset += sizeof(this->lifetime.nsec);
      union {
        bool real;
        uint8_t base;
      } u_frame_locked;
      u_frame_locked.real = this->frame_locked;
      *(outbuffer + offset + 0) = (u_frame_locked.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->frame_locked);
      *(outbuffer + offset + 0) = (this->metadata_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->metadata_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->metadata_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->metadata_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->metadata_length);
      for( uint32_t i = 0; i < metadata_length; i++){
      offset += this->metadata[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset + 0) = (this->attributes_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->attributes_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->attributes_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->attributes_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->attributes_length);
      for( uint32_t i = 0; i < attributes_length; i++){
      offset += this->attributes[i].serialize(outbuffer + offset);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->timestamp.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.sec);
      this->timestamp.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->timestamp.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->timestamp.nsec);
      uint32_t length_frame_id;
      arrToVar(length_frame_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_frame_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_frame_id-1]=0;
      this->frame_id = (char *)(inbuffer + offset-1);
      offset += length_frame_id;
      uint32_t length_id;
      arrToVar(length_id, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_id; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_id-1]=0;
      this->id = (char *)(inbuffer + offset-1);
      offset += length_id;
      this->lifetime.sec =  ((uint32_t) (*(inbuffer + offset)));
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->lifetime.sec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->lifetime.sec);
      this->lifetime.nsec =  ((uint32_t) (*(inbuffer + offset)));
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->lifetime.nsec |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->lifetime.nsec);
      union {
        bool real;
        uint8_t base;
      } u_frame_locked;
      u_frame_locked.base = 0;
      u_frame_locked.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->frame_locked = u_frame_locked.real;
      offset += sizeof(this->frame_locked);
      uint32_t metadata_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      metadata_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->metadata_length);
      if(metadata_lengthT > metadata_length)
        this->metadata = (foxglove_msgs::KeyValuePair*)realloc(this->metadata, metadata_lengthT * sizeof(foxglove_msgs::KeyValuePair));
      metadata_length = metadata_lengthT;
      for( uint32_t i = 0; i < metadata_length; i++){
      offset += this->st_metadata.deserialize(inbuffer + offset);
        memcpy( &(this->metadata[i]), &(this->st_metadata), sizeof(foxglove_msgs::KeyValuePair));
      }
      uint32_t attributes_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      attributes_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      attributes_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      attributes_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->attributes_length);
      if(attributes_lengthT > attributes_length)
        this->attributes = (foxglove_msgs::SphereAttributes*)realloc(this->attributes, attributes_lengthT * sizeof(foxglove_msgs::SphereAttributes));
      attributes_length = attributes_lengthT;
      for( uint32_t i = 0; i < attributes_length; i++){
      offset += this->st_attributes.deserialize(inbuffer + offset);
        memcpy( &(this->attributes[i]), &(this->st_attributes), sizeof(foxglove_msgs::SphereAttributes));
      }
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/SphereListMarker"; };
    virtual const char * getMD5() override { return "513e3357acd626f0c0b0be86b43f2399"; };

  };

}
#endif
