#ifndef _ROS_foxglove_msgs_ConeMarker_h
#define _ROS_foxglove_msgs_ConeMarker_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/Vector3.h"
#include "foxglove_msgs/Color.h"

namespace foxglove_msgs
{

  class ConeMarker : public ros::Msg
  {
    public:
      typedef geometry_msgs::Pose _pose_type;
      _pose_type pose;
      typedef geometry_msgs::Vector3 _size_type;
      _size_type size;
      typedef double _bottom_scale_type;
      _bottom_scale_type bottom_scale;
      typedef double _top_scale_type;
      _top_scale_type top_scale;
      typedef foxglove_msgs::Color _color_type;
      _color_type color;

    ConeMarker():
      pose(),
      size(),
      bottom_scale(0),
      top_scale(0),
      color()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += this->pose.serialize(outbuffer + offset);
      offset += this->size.serialize(outbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_bottom_scale;
      u_bottom_scale.real = this->bottom_scale;
      *(outbuffer + offset + 0) = (u_bottom_scale.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_bottom_scale.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_bottom_scale.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_bottom_scale.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_bottom_scale.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_bottom_scale.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_bottom_scale.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_bottom_scale.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->bottom_scale);
      union {
        double real;
        uint64_t base;
      } u_top_scale;
      u_top_scale.real = this->top_scale;
      *(outbuffer + offset + 0) = (u_top_scale.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_top_scale.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_top_scale.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_top_scale.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_top_scale.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_top_scale.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_top_scale.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_top_scale.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->top_scale);
      offset += this->color.serialize(outbuffer + offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += this->pose.deserialize(inbuffer + offset);
      offset += this->size.deserialize(inbuffer + offset);
      union {
        double real;
        uint64_t base;
      } u_bottom_scale;
      u_bottom_scale.base = 0;
      u_bottom_scale.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_bottom_scale.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_bottom_scale.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_bottom_scale.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_bottom_scale.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_bottom_scale.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_bottom_scale.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_bottom_scale.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->bottom_scale = u_bottom_scale.real;
      offset += sizeof(this->bottom_scale);
      union {
        double real;
        uint64_t base;
      } u_top_scale;
      u_top_scale.base = 0;
      u_top_scale.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_top_scale.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_top_scale.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_top_scale.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_top_scale.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_top_scale.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_top_scale.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_top_scale.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->top_scale = u_top_scale.real;
      offset += sizeof(this->top_scale);
      offset += this->color.deserialize(inbuffer + offset);
     return offset;
    }

    virtual const char * getType() override { return "foxglove_msgs/ConeMarker"; };
    virtual const char * getMD5() override { return "95a94410f04d20228465a960c3c3f66f"; };

  };

}
#endif
