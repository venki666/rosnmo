#ifndef _ROS_example_ros_msg_ExampleMessage_h
#define _ROS_example_ros_msg_ExampleMessage_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace example_ros_msg
{

  class ExampleMessage : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      typedef int32_t _demo_int_type;
      _demo_int_type demo_int;
      typedef double _demo_double_type;
      _demo_double_type demo_double;

    ExampleMessage():
      header(),
      demo_int(0),
      demo_double(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      union {
        int32_t real;
        uint32_t base;
      } u_demo_int;
      u_demo_int.real = this->demo_int;
      *(outbuffer + offset + 0) = (u_demo_int.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_demo_int.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_demo_int.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_demo_int.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->demo_int);
      union {
        double real;
        uint64_t base;
      } u_demo_double;
      u_demo_double.real = this->demo_double;
      *(outbuffer + offset + 0) = (u_demo_double.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_demo_double.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_demo_double.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_demo_double.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_demo_double.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_demo_double.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_demo_double.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_demo_double.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->demo_double);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      union {
        int32_t real;
        uint32_t base;
      } u_demo_int;
      u_demo_int.base = 0;
      u_demo_int.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_demo_int.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_demo_int.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_demo_int.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->demo_int = u_demo_int.real;
      offset += sizeof(this->demo_int);
      union {
        double real;
        uint64_t base;
      } u_demo_double;
      u_demo_double.base = 0;
      u_demo_double.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_demo_double.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_demo_double.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_demo_double.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_demo_double.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_demo_double.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_demo_double.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_demo_double.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->demo_double = u_demo_double.real;
      offset += sizeof(this->demo_double);
     return offset;
    }

    virtual const char * getType() override { return "example_ros_msg/ExampleMessage"; };
    virtual const char * getMD5() override { return "4bff6c3cd06bdff0e8adfcc89c6e9870"; };

  };

}
#endif
